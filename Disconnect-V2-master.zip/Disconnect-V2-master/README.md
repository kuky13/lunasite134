# Disconnect

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/287e9aa9df254c809554d46fd1af1ba9)](https://app.codacy.com/gh/DevCytech/Disconnect?utm_source=github.com&utm_medium=referral&utm_content=DevCytech/Disconnect&utm_campaign=Badge_Grade_Settings)

Made with love to be the glue to your community. Keep your community together and active!

## About

Disconnect is a multi-purpose Discord Bot built around giving a simple and fun environment to your community. Yes there are many fancy features on the bot but they are all implemented in a simple ways in order to make it less of a head-ache compared to other Discord Bots.

## Quick Start

1. Invite Disconnect to your guild. ([Click here to invite Disconnect](https://disconnectbot.com/invite.html))
2. Change the prefix to a prefix of your liking using the `set-prefix` command.
3. Then you are all set to go!! Enjoy!

## Bit o History

Disconnect was a project started by Cytech to be a learning project to learn how to code. Later on, Cytech released the bot to the public and it slowly grew, and being amazed by the mini success he continued working on Disconnect into what it is today. Up until this point it's always been just him working on Disconnect and it still just is. The rewrite for Disconnect (Which was released alongside this website) was done to improve some of the previous bots bugs and update to the newest of the Discord API. The Disconnect Site was thought of a long time ago in the begging to get into front-end development and it's finally become a reality after a year in the making. And who is to say this where the progress ends.

## Latest Update: V2.2.1 - **The Music Update Patches**

-   Twitter should now update properly after adding a new Twitter account to follow
-   Fixed two errors causing the bot to go down.
