// Setup the environment
require('dotenv').config();

// Start up the bot
require('./src/bot.js');
