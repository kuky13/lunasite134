# Command Template

This is the general command template.

```js
// Template
module.exports.run = async ({}) => {};

module.exports.config = {
	name: '',
	aliases: [],
};
```
